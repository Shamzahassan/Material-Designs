package work.shh.com.materialdesings;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    EditText edt_1, edt_2;
    LinearLayout layout;
    Button btn;
    View bottom_sheet;
    private BottomSheetBehavior mBottomSheetBehavior;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        edt_1 = (EditText) findViewById(R.id.edt_1);
        edt_2 = (EditText) findViewById(R.id.edt_2);
        layout = (LinearLayout) findViewById(R.id.layout);
        btn = (Button) findViewById(R.id.btn);
        bottom_sheet=  findViewById(R.id.bottom_sheet);



        mBottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {

            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });

        mBottomSheetBehavior.setPeekHeight(300);
        mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
         /*       Snackbar snackbar = Snackbar
                        .make(layout, "Material Work", Snackbar.LENGTH_LONG);

                snackbar.show();*/

                Snackbar snackbar = Snackbar
                        .make(layout, "Thanks", Snackbar.LENGTH_LONG)
                        .setAction("TAP ME", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Snackbar snackbar1 = Snackbar.make(layout, "Welcome!", Snackbar.LENGTH_SHORT);
                                snackbar1.show();
                            }
                        });

                snackbar.show();
            }
        });


    }
}
